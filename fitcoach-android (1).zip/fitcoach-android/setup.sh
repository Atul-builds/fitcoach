#!/usr/bin/env bash
# Run once on Mac/Linux (on Windows use Git Bash). Needs Node.js 18+ and Android Studio.
set -e
npm install
npx cap add android
PKG=android/app/src/main/java/com/atul/fitcoach
mkdir -p "$PKG"
cp android-files/StepCounterPlugin.java android-files/MainActivity.java "$PKG/"
MANIFEST=android/app/src/main/AndroidManifest.xml
if ! grep -q ACTIVITY_RECOGNITION "$MANIFEST"; then
  sed -i.bak 's|<application|<uses-permission android:name="android.permission.ACTIVITY_RECOGNITION"/>\n    <uses-permission android:name="android.permission.POST_NOTIFICATIONS"/>\n    <uses-permission android:name="android.permission.ACCESS_FINE_LOCATION"/>\n    <uses-permission android:name="android.permission.ACCESS_COARSE_LOCATION"/>\n    <application|' "$MANIFEST"
fi
npx cap sync android
echo "Done. Now run: npx cap open android  (then Build > Build APK)"
