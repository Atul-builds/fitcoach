"use strict";

// Compatibility for older Android WebView versions
if (typeof structuredClone !== "function") window.structuredClone = (v) => JSON.parse(JSON.stringify(v));
if (!Element.prototype.replaceChildren) Element.prototype.replaceChildren = function (...n) { while (this.firstChild) this.removeChild(this.firstChild); n.forEach(x => this.append(x)); };


const $ = (id) => document.getElementById(id);
// Native (Android app) bridge. In a normal browser these stay null and the web fallbacks are used.
const NATIVE = !!(window.Capacitor && window.Capacitor.isNativePlatform && window.Capacitor.isNativePlatform());
const StepPlugin = NATIVE ? window.Capacitor.registerPlugin("StepCounter") : null;
const LN = NATIVE ? window.Capacitor.registerPlugin("LocalNotifications") : null;
const STORAGE_KEY = "fitcoach_v1";
const EXERCISES = [
  { name: "Push-ups", info: "3 sets · 8 reps", tip: "Modify on knees if needed." },
  { name: "Bodyweight squats", info: "3 sets · 12 reps", tip: "Move slowly and comfortably." },
  { name: "Plank", info: "3 sets · 20 seconds", tip: "Keep your body aligned." },
  { name: "Walking", info: "10 minutes", tip: "Choose a comfortable pace." }
];

const dayKey = (d = new Date()) => d.toLocaleDateString("en-CA");

const defaultData = {
  day: "", goal: 8000, water: 0, meals: [], weights: [], workouts: [], steps: 0,
  run: { distance: 0, seconds: 0, calories: 0 },
  history: {}, runs: [],
  exercises: EXERCISES.map(e => ({ ...e })),
  profile: { height: 0 },
  settings: { waterOn: false, waterEvery: 60, workoutOn: false, workoutTime: "18:00",
              lastWater: 0, nativeLast: null, restLength: 60, sound: true, lastWorkoutDay: "", goalNotifiedDay: "" }
};

function loadData() {
  try {
    const s = JSON.parse(localStorage.getItem(STORAGE_KEY));
    if (s && typeof s === "object") {
      const d = structuredClone(defaultData);
      Object.assign(d, s);
      d.run = { ...defaultData.run, ...(s.run || {}) };
      d.profile = { ...defaultData.profile, ...(s.profile || {}) };
      d.settings = { ...defaultData.settings, ...(s.settings || {}) };
      return d;
    }
  } catch (e) { console.warn("Could not load saved data", e); }
  return structuredClone(defaultData);
}

let data = loadData();

function saveData() {
  try { localStorage.setItem(STORAGE_KEY, JSON.stringify(data)); }
  catch { toast("Could not save. Browser storage may be full."); }
}

function toast(msg) {
  const t = $("toast");
  t.textContent = msg;
  t.classList.add("show");
  clearTimeout(toast.t);
  toast.t = setTimeout(() => t.classList.remove("show"), 3000);
}

const safeNumber = (v, f = 0) => { const n = Number(v); return Number.isFinite(n) ? n : f; };
const escapeHTML = (v) => String(v).replace(/[&<>"']/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[c]);

function formatTime(sec) {
  const s = Math.max(0, Math.floor(sec));
  return [Math.floor(s / 3600), Math.floor(s % 3600 / 60), s % 60].map(n => String(n).padStart(2, "0")).join(":");
}

// FIXED: pace = seconds per km, split into min:sec
function formatPace(km, sec) {
  if (km < 0.02 || sec <= 0) return "--:--";
  const perKm = sec / km;
  if (perKm > 3600) return "--:--";
  let m = Math.floor(perKm / 60), s = Math.round(perKm % 60);
  if (s === 60) { m++; s = 0; }
  return `${m}:${String(s).padStart(2, "0")}`;
}

const latestWeight = () => data.weights.length ? safeNumber(data.weights[data.weights.length - 1].weight, 60) : 60;
const strideM = () => data.profile.height > 0 ? data.profile.height * 0.415 / 100 : 0.75;

// MET values by speed (km/h) for walking/running
function met(kmh) {
  if (kmh < 3) return 2.3;
  if (kmh < 5) return 3.5;
  if (kmh < 6.5) return 4.5;
  if (kmh < 8) return 7;
  if (kmh < 10) return 9.3;
  if (kmh < 12) return 11;
  return 12.5;
}

// ---------- Daily rollover ----------
function rollDay() {
  const today = dayKey();
  if (data.day === today) return;
  if (data.day) {
    data.history[data.day] = { steps: data.steps, km: data.run.distance, kcal: data.run.calories, goal: data.goal };
  }
  data.day = today;
  data.water = 0; data.meals = []; data.workouts = []; data.steps = 0;
  if (!tracking) data.run = { distance: 0, seconds: 0, calories: 0 };
  data.settings.lastWater = Date.now();
  saveData();
}

// ---------- Navigation ----------
function showPage(name) {
  document.querySelectorAll(".page").forEach(p => p.classList.toggle("active", p.id === name));
  document.querySelectorAll(".nav-btn").forEach(b => {
    const on = b.dataset.page === name;
    b.classList.toggle("active", on);
    on ? b.setAttribute("aria-current", "page") : b.removeAttribute("aria-current");
  });
  window.scrollTo({ top: 0 });
  render();
}
document.querySelectorAll("[data-page]").forEach(b => b.addEventListener("click", () => showPage(b.dataset.page)));

// ---------- Rendering ----------
function weekData() {
  const out = [];
  for (let i = 6; i >= 0; i--) {
    const d = new Date(); d.setDate(d.getDate() - i);
    const h = i === 0 ? { steps: data.steps, goal: data.goal } : data.history[dayKey(d)];
    out.push({
      label: d.toLocaleDateString("en", { weekday: "short" }).slice(0, 2),
      full: d.toLocaleDateString("en", { weekday: "short", day: "numeric", month: "short" }),
      steps: h ? Math.round(h.steps) : 0, goal: h ? (h.goal || data.goal) : data.goal, today: i === 0
    });
  }
  return out;
}

const shortNum = n => n >= 1000 ? (n / 1000).toFixed(n >= 10000 ? 0 : 1) + "k" : String(n);

function renderBars(id) {
  const week = weekData();
  const max = Math.max(1, data.goal, ...week.map(w => w.steps));
  $(id).innerHTML = week.map(w =>
    `<div class="bar-col" title="${w.steps.toLocaleString()} steps"><b>${shortNum(w.steps)}</b><div class="bar ${w.today ? "today" : w.steps >= w.goal ? "hit" : ""}" style="height:${Math.round(w.steps / max * 100)}%"></div><span>${w.label}</span></div>`
  ).join("");
}

function renderDaily() {
  const html = weekData().slice().reverse().map(w =>
    `<div class="run-row"><div><strong>${w.full}${w.today ? " (today)" : ""}</strong><p class="muted">${(w.steps * strideM() / 1000).toFixed(2)} km${w.steps >= w.goal ? " · goal met" : ""}</p></div><div><strong>${w.steps.toLocaleString()}</strong> <span class="muted">steps</span></div></div>`
  ).join("");
  ["dailyA", "dailyB"].forEach(id => { if ($(id)) $(id).innerHTML = html; });
}

function renderSummary() {
  const steps = Math.max(0, Math.floor(safeNumber(data.steps)));
  const goal = Math.max(1, safeNumber(data.goal, 8000));
  const pct = Math.min(100, Math.round(steps / goal * 100));
  const hour = new Date().getHours();
  $("greet").textContent = hour < 12 ? "Good morning" : hour < 17 ? "Good afternoon" : "Good evening";
  $("todayLabel").textContent = new Date().toLocaleDateString("en", { weekday: "long", day: "numeric", month: "short" });

  $("homeSteps").textContent = steps.toLocaleString();
  $("goalLeft").textContent = Math.max(0, goal - steps).toLocaleString();
  $("stepPercent").textContent = `${pct}%`;
  $("stepPercent2").textContent = `${pct}%`;
  $("stepRing").style.setProperty("--progress", `${pct}%`);
  $("stepRing2").style.setProperty("--progress", `${pct}%`);
  $("stepsBig").textContent = steps.toLocaleString();
  $("stepKm").textContent = (steps * strideM() / 1000).toFixed(2);
  $("stepKcal").textContent = Math.round(steps * 0.04 * latestWeight() / 60);

  $("waterCount").textContent = data.water;
  $("workoutCount").innerHTML = `${data.workouts.filter(Boolean).length} <small>/ ${data.exercises.length} done</small>`;
  if (document.activeElement !== $("stepGoal")) $("stepGoal").value = goal;
  if (document.activeElement !== $("heightInput")) $("heightInput").value = data.profile.height || "";

  $("pocketSteps").textContent = steps.toLocaleString();
  renderBars("weekHome"); renderBars("weekSteps"); renderBars("weekProgress"); renderDaily();
  const week = weekData();
  const hit = week.filter(w => w.steps >= w.goal).length;
  const avg = Math.round(week.reduce((a, w) => a + w.steps, 0) / 7);
  $("weekSummary").textContent = `Goal reached on ${hit} of 7 days · average ${avg.toLocaleString()} steps/day`;
  updateRunDisplay();
}

function renderMeals() {
  const cal = data.meals.reduce((s, m) => s + safeNumber(m.calories), 0);
  const pro = data.meals.reduce((s, m) => s + safeNumber(m.protein), 0);
  $("totalCalories").textContent = `${Math.round(cal)} kcal`;
  $("totalProtein").textContent = `${pro.toFixed(1)} g`;
  const list = $("mealList");
  list.replaceChildren();
  if (!data.meals.length) { list.className = "stack muted"; list.textContent = "No meals yet. Add your first meal above."; return; }
  list.className = "stack";
  data.meals.forEach((m, i) => {
    const row = document.createElement("article");
    row.className = "meal-row";
    row.innerHTML = `<div><strong>${escapeHTML(m.name)}</strong><p class="muted">${m.calories} kcal · ${m.protein} g protein</p></div>
      <button class="small-btn" data-delete-meal="${i}" aria-label="Delete ${escapeHTML(m.name)}">Delete</button>`;
    list.appendChild(row);
  });
}

function renderWorkouts() {
  const list = $("workoutList");
  list.replaceChildren();
  if (!data.exercises.length) { list.className = "stack muted"; list.textContent = "No exercises yet. Add your first one below."; return; }
  list.className = "stack";
  data.exercises.forEach((ex, i) => {
    const row = document.createElement("article");
    row.className = "exercise-row";
    const label = document.createElement("label");
    const cb = document.createElement("input");
    cb.type = "checkbox";
    cb.checked = Boolean(data.workouts[i]);
    cb.setAttribute("aria-label", `Complete ${ex.name}`);
    cb.addEventListener("change", () => {
      data.workouts[i] = cb.checked; saveData(); renderSummary();
      if (data.exercises.length && data.workouts.filter(Boolean).length === data.exercises.length) {
        toast("Workout complete. Great job!"); chime();
        notify("Workout complete", "You finished today's routine. Great job!", "workout-done");
      }
    });
    const info = document.createElement("div");
    info.innerHTML = `<strong>${escapeHTML(ex.name)}</strong><p class="muted">${escapeHTML(ex.info || "")}</p>${ex.tip ? `<p class="muted">${escapeHTML(ex.tip)}</p>` : ""}`;
    label.append(cb, info);
    const del = document.createElement("button");
    del.className = "small-btn"; del.textContent = "Delete";
    del.setAttribute("aria-label", `Delete ${ex.name}`);
    del.addEventListener("click", () => { data.exercises.splice(i, 1); data.workouts.splice(i, 1); saveData(); render(); });
    row.append(label, del);
    list.appendChild(row);
  });
}

function renderWeights() {
  const list = $("weightList");
  list.replaceChildren();
  [...data.weights].reverse().slice(0, 7).forEach(w => {
    const r = document.createElement("div");
    r.className = "weight-row";
    r.textContent = `${w.date} — ${safeNumber(w.weight).toFixed(1)} kg`;
    list.appendChild(r);
  });
  const h = data.profile.height;
  $("bmiText").textContent = h > 0 && data.weights.length
    ? `BMI ${(latestWeight() / ((h / 100) ** 2)).toFixed(1)} (a general guide only, not a diagnosis)`
    : "Add your height and weight to see BMI.";
}

function renderRuns() {
  const list = $("runList");
  list.replaceChildren();
  if (!data.runs.length) { list.className = "stack muted"; list.textContent = "No runs yet. Tap Start run."; return; }
  list.className = "stack";
  data.runs.slice(0, 5).forEach(r => {
    const row = document.createElement("div");
    row.className = "run-row";
    row.innerHTML = `<div><strong>${r.km.toFixed(2)} km</strong><p class="muted">${escapeHTML(r.date)} · ${formatTime(r.sec)}</p></div>
      <div class="muted">${formatPace(r.km, r.sec)} /km · ${Math.round(r.kcal)} kcal</div>`;
    list.appendChild(row);
  });
}

function renderNotifSettings() {
  const st = data.settings;
  $("waterRemind").checked = st.waterOn;
  $("waterEvery").value = String(st.waterEvery);
  $("workoutRemind").checked = st.workoutOn;
  $("workoutTime").value = st.workoutTime;
  if (NATIVE) { $("notifStatus").textContent = "Reminders are scheduled on your phone and work even when the app is closed."; return; }
  const supported = "Notification" in window;
  $("notifStatus").textContent = !supported ? "This browser does not support notifications."
    : Notification.permission === "granted" ? "Notifications are on."
    : Notification.permission === "denied" ? "Notifications are blocked. Allow them in your browser's site settings."
    : "Notifications are off.";
  $("notifEnable").hidden = supported && Notification.permission === "granted";
}

function render() { renderSummary(); renderMeals(); renderWorkouts(); renderWeights(); renderRuns(); renderNotifSettings(); }

// ---------- Basic inputs ----------
$("exerciseForm").addEventListener("submit", e => {
  e.preventDefault();
  const name = $("exName").value.trim(), info = $("exInfo").value.trim();
  if (!name) return toast("Enter an exercise name.");
  data.exercises.push({ name, info: info || "Your own exercise", tip: "" });
  saveData(); e.target.reset(); render(); toast("Exercise added.");
});

$("addWater").addEventListener("click", () => {
  data.water = Math.min(30, data.water + 1);
  data.settings.lastWater = Date.now();
  saveData(); renderSummary();
  if (data.water === 8) toast("Water goal reached!");
});

$("mealForm").addEventListener("submit", e => {
  e.preventDefault();
  const name = $("mealName").value.trim();
  const calories = safeNumber($("mealCalories").value, -1);
  const protein = safeNumber($("mealProtein").value, -1);
  if (!name || calories < 0 || protein < 0) return toast("Please enter valid meal details.");
  data.meals.push({ name, calories, protein });
  saveData(); e.target.reset(); renderMeals(); toast("Meal saved.");
});

$("mealList").addEventListener("click", e => {
  const b = e.target.closest("[data-delete-meal]");
  if (!b) return;
  data.meals.splice(Number(b.dataset.deleteMeal), 1);
  saveData(); renderMeals();
});

$("saveGoal").addEventListener("click", () => {
  const goal = safeNumber($("stepGoal").value, 0);
  const height = safeNumber($("heightInput").value, 0);
  if (goal < 100 || goal > 100000) return toast("Goal must be between 100 and 100,000 steps.");
  if (height && (height < 50 || height > 250)) return toast("Height must be between 50 and 250 cm.");
  data.goal = goal; data.profile.height = height;
  saveData(); render(); toast("Saved.");
});

$("weightForm").addEventListener("submit", e => {
  e.preventDefault();
  const w = safeNumber($("weightInput").value, 0);
  if (w <= 0 || w > 500) return toast("Enter a valid weight in kg.");
  data.weights.push({ weight: w, date: new Date().toLocaleDateString() });
  saveData(); $("weightInput").value = ""; renderWeights(); toast("Weight saved.");
});

// Home: edit goal / add steps
let heroMode = null;
function openHero(mode) {
  heroMode = mode; $("heroEdit").hidden = false;
  $("heroInput").value = mode === "goal" ? data.goal : "";
  $("heroInput").placeholder = mode === "goal" ? "New daily step goal" : "Steps to add";
  $("heroInput").focus();
}
$("editGoalBtn").addEventListener("click", () => openHero("goal"));
$("addStepsBtn").addEventListener("click", () => openHero("steps"));
$("heroSave").addEventListener("click", () => {
  const n = Math.floor(safeNumber($("heroInput").value, 0));
  if (heroMode === "goal") {
    if (n < 100 || n > 100000) return toast("Goal must be between 100 and 100,000 steps.");
    data.goal = n; data.settings.goalNotifiedDay = data.steps >= n ? dayKey() : ""; toast("Goal updated.");
  } else {
    if (n < 1 || n > 50000) return toast("Enter between 1 and 50,000 steps.");
    addSteps(n); toast(`${n.toLocaleString()} steps added.`);
  }
  saveData(); renderSummary(); $("heroEdit").hidden = true;
});

// ---------- Notifications ----------
async function notify(title, body, tag = "fitcoach") {
  toast(`${title}: ${body}`);
  if (NATIVE) {
    try { await LN.schedule({ notifications: [{ id: Math.floor(Math.random() * 2e9), title, body, schedule: { at: new Date(Date.now() + 500) } }] }); } catch {}
    return;
  }
  if (!("Notification" in window) || Notification.permission !== "granted") return;
  const opts = { body, tag, icon: "./icons/icon-192.png", badge: "./icons/icon-192.png", vibrate: [120, 60, 120] };
  try {
    const reg = await navigator.serviceWorker?.ready;
    if (reg) return reg.showNotification(title, opts);
  } catch {}
  try { new Notification(title, opts); } catch {}
}

$("notifEnable").addEventListener("click", async () => {
  if (NATIVE) { try { const r = await LN.requestPermissions(); toast(r.display === "granted" ? "Notifications enabled." : "Notifications blocked in phone settings."); scheduleNative(); } catch {} return; }
  if (!("Notification" in window)) return toast("Notifications are not supported here.");
  await Notification.requestPermission();
  renderNotifSettings();
  if (Notification.permission === "granted") notify("Notifications on", "FitCoach reminders are ready.", "welcome");
});
$("testNotif").addEventListener("click", () => {
  if (NATIVE) return notify("FitCoach", "This is a test notification.", "test");
  if (!("Notification" in window) || Notification.permission !== "granted") return toast("Enable notifications first.");
  notify("FitCoach", "This is a test notification.", "test");
});
const saveSettings = () => {
  Object.assign(data.settings, {
    waterOn: $("waterRemind").checked, waterEvery: Number($("waterEvery").value),
    workoutOn: $("workoutRemind").checked, workoutTime: $("workoutTime").value || "18:00"
  });
  saveData(); scheduleNative();
  if ((data.settings.waterOn || data.settings.workoutOn) && "Notification" in window && Notification.permission !== "granted") toast("Tap Enable notifications to receive reminders.");
};
["waterRemind", "waterEvery", "workoutRemind", "workoutTime"].forEach(id => $(id).addEventListener("change", saveSettings));

async function scheduleNative() {
  if (!NATIVE) return;
  const st = data.settings;
  try {
    const ids = [{ id: 101 }]; for (let h = 0; h < 24; h++) ids.push({ id: 200 + h });
    await LN.cancel({ notifications: ids });
    const list = [];
    if (st.workoutOn) { const [hh, mm] = st.workoutTime.split(":").map(Number);
      list.push({ id: 101, title: "Workout time", body: "Your daily routine is waiting. Even 10 minutes counts.", schedule: { on: { hour: hh, minute: mm }, allowWhileIdle: true } }); }
    if (st.waterOn) { const step = Math.max(1, Math.round(st.waterEvery / 60));
      for (let h = 8; h <= 21; h += step) list.push({ id: 200 + h, title: "Time to hydrate", body: "Drink a glass of water.", schedule: { on: { hour: h, minute: 0 }, allowWhileIdle: true } }); }
    if (list.length) await LN.schedule({ notifications: list });
  } catch (e) { console.warn(e); }
}

function checkReminders() {
  rollDay();
  if (NATIVE) return;
  const st = data.settings, now = new Date(), hr = now.getHours();
  if (st.waterOn && data.water < 8 && hr >= 7 && hr < 22 && Date.now() - st.lastWater >= st.waterEvery * 60000) {
    st.lastWater = Date.now(); saveData();
    notify("Time to hydrate", `${data.water} of 8 glasses so far. Drink a glass of water.`, "water");
  }
  const hhmm = `${String(hr).padStart(2, "0")}:${String(now.getMinutes()).padStart(2, "0")}`;
  if (st.workoutOn && st.lastWorkoutDay !== dayKey() && hhmm >= st.workoutTime && data.workouts.filter(Boolean).length < data.exercises.length) {
    st.lastWorkoutDay = dayKey(); saveData();
    notify("Workout time", "Your daily routine is waiting. Even 10 minutes counts.", "workout");
  }
}
setInterval(checkReminders, 30000);

// ---------- Steps ----------
function addSteps(n) {
  data.steps += n;
  if (data.steps >= data.goal && data.settings.goalNotifiedDay !== dayKey()) {
    data.settings.goalNotifiedDay = dayKey();
    chime();
    notify("Step goal reached", `You hit ${data.goal.toLocaleString()} steps today. Well done!`, "goal");
  }
  if (!addSteps.t) addSteps.t = setTimeout(() => { addSteps.t = null; saveData(); renderSummary(); }, 1000);
}

let motionOn = false, gotMotion = false, grav = 9.8, sm = 0, above = false, lastStep = 0;
function onMotion(e) {
  const a = e.accelerationIncludingGravity;
  if (!a) return;
  gotMotion = true;
  const m = Math.hypot(a.x || 0, a.y || 0, a.z || 0);
  grav = grav * 0.9 + m * 0.1;
  sm = sm * 0.6 + (m - grav) * 0.4;
  const now = Date.now();
  if (sm > 1.3 && !above && now - lastStep > 300) { above = true; lastStep = now; addSteps(1); }
  else if (sm < 0.5) above = false;
}

async function startStepCounter(fromTap = false) {
  if (motionOn) return;
  if (!("DeviceMotionEvent" in window)) { $("stepsStatus").textContent = "Motion sensor not available on this device."; return; }
  try {
    if (typeof DeviceMotionEvent.requestPermission === "function") {
      if (!fromTap) { $("stepsStatus").textContent = "Tap anywhere once to allow step counting (iPhone)."; return; }
      if (await DeviceMotionEvent.requestPermission() !== "granted") { $("stepsStatus").textContent = "Motion permission denied."; return; }
    }
  } catch { $("stepsStatus").textContent = "Could not get motion permission."; return; }
  gotMotion = false; motionOn = true;
  window.addEventListener("devicemotion", onMotion);
  $("toggleSteps").textContent = "Pause counting";
  $("stepsStatus").textContent = "Counting automatically. Keep FitCoach open while you walk.";
  setTimeout(() => { if (motionOn && !gotMotion) $("stepsStatus").textContent = "No sensor data received. Open the app over HTTPS in Chrome or Safari."; }, 4000);
}

function stopStepCounter() {
  window.removeEventListener("devicemotion", onMotion);
  motionOn = false;
  $("toggleSteps").textContent = "Resume counting";
  $("stepsStatus").textContent = "Counting paused.";
}

$("toggleSteps").addEventListener("click", () => {
  if (motionOn) { data.settings.autoSteps = false; saveData(); stopStepCounter(); }
  else { data.settings.autoSteps = true; saveData(); startStepCounter(true); }
});

// Android app: the phone's hardware step counter keeps counting with the screen off.
// We read its running total and add what changed since the last read.
async function syncNativeSteps() {
  try {
    rollDay();
    const { total } = await StepPlugin.getTotal();
    const st = data.settings;
    if (st.nativeLast == null) st.nativeLast = total;
    else { let d = total - st.nativeLast; if (d < 0) d = total; if (d > 0 && d < 100000) addSteps(Math.round(d)); st.nativeLast = total; }
    saveData();
    $("stepsStatus").textContent = `Counting in the background with your phone's step sensor. Sensor total ${Math.round(total)} · synced ${new Date().toLocaleTimeString("en", { hour: "numeric", minute: "2-digit" })}`;
    renderSummary();
  } catch (e) { $("stepsStatus").textContent = `Step sensor problem: ${(e && e.message) || e}. Allow Physical activity in the app's settings.`; }
}

// Auto-start on open; iPhone needs one tap for the permission prompt.
function autoStartSteps() {
  if (NATIVE) {
    $("toggleSteps").style.display = "none"; $("pocketBtn").style.display = "none";
    syncNativeSteps(); setInterval(syncNativeSteps, 15000);
    document.addEventListener("visibilitychange", () => { if (document.visibilityState === "visible") syncNativeSteps(); });
    ["focus", "pageshow", "resume"].forEach(ev => window.addEventListener(ev, syncNativeSteps));
    return;
  }
  if (data.settings.autoSteps === false || motionOn) return;
  startStepCounter(false);
  if (typeof DeviceMotionEvent !== "undefined" && typeof DeviceMotionEvent.requestPermission === "function") {
    document.addEventListener("click", () => startStepCounter(true), { once: true });
  }
}

// Screen wake lock (run tracking + pocket mode)
let wakeLock = null, pocket = false;
async function requestWake() {
  try { await wakeLock?.release?.(); wakeLock = await navigator.wakeLock?.request("screen"); } catch {}
}
function releaseWake() { if (!tracking && !pocket) { wakeLock?.release?.().catch(() => {}); wakeLock = null; } }
document.addEventListener("visibilitychange", () => { if (document.visibilityState === "visible" && (tracking || pocket)) requestWake(); });

// Pocket mode: black screen, screen stays on, steps keep counting
async function enterPocket() {
  if (!motionOn) { data.settings.autoSteps = true; saveData(); await startStepCounter(true); }
  if (!motionOn) return toast("Step sensor is not available.");
  if (!navigator.wakeLock) toast("This browser cannot keep the screen on.");
  pocket = true; requestWake(); $("pocket").hidden = false; renderSummary();
}
function exitPocket() { pocket = false; $("pocket").hidden = true; releaseWake(); }
$("pocketBtn").addEventListener("click", enterPocket);
let holdT = null;
const holdStart = () => { holdT = setTimeout(exitPocket, 1500); };
const holdEnd = () => clearTimeout(holdT);
["pointerdown"].forEach(e => $("pocketExit").addEventListener(e, holdStart));
["pointerup", "pointerleave", "pointercancel"].forEach(e => $("pocketExit").addEventListener(e, holdEnd));

// Offline badge + install button
function netState() { const on = navigator.onLine; $("netBadge").textContent = on ? "Online" : "Offline mode"; $("netBadge").className = "net " + (on ? "on" : "off"); }
window.addEventListener("online", netState); window.addEventListener("offline", netState); netState();
let installEvt = null;
window.addEventListener("beforeinstallprompt", e => { e.preventDefault(); installEvt = e; $("installBtn").hidden = false; });
$("installBtn").addEventListener("click", async () => { if (!installEvt) return; installEvt.prompt(); await installEvt.userChoice; installEvt = null; $("installBtn").hidden = true; });
window.addEventListener("appinstalled", () => { $("installBtn").hidden = true; toast("FitCoach installed."); });

// ---------- Run tracker ----------
let gpsWatchId = null, runTimer = null, lastPoint = null, lastTime = 0;
let runAccum = 0, segStart = 0, tracking = false, paused = false, lastKmMark = 0;

const runSeconds = () => tracking && !paused ? runAccum + (Date.now() - segStart) / 1000 : runAccum;

function updateRunDisplay() {
  const km = data.run.distance, sec = tracking ? runSeconds() : data.run.seconds;
  const speed = sec > 0 ? km / (sec / 3600) : 0;
  $("distance").textContent = km.toFixed(2);
  $("timer").textContent = formatTime(sec);
  $("pace").innerHTML = `${formatPace(km, sec)} <small>/km</small>`;
  $("speed").innerHTML = `${speed.toFixed(1)} <small>km/h</small>`;
  $("runCalories").innerHTML = `${Math.round(data.run.calories)} <small>kcal</small>`;
  $("homeKm").textContent = km.toFixed(2);
  $("homeBurn").textContent = Math.round(data.run.calories);
}

function distanceKm(a, b) {
  const r = v => v * Math.PI / 180;
  const dLat = r(b.latitude - a.latitude), dLon = r(b.longitude - a.longitude);
  const h = Math.sin(dLat / 2) ** 2 + Math.cos(r(a.latitude)) * Math.cos(r(b.latitude)) * Math.sin(dLon / 2) ** 2;
  return 6371 * 2 * Math.atan2(Math.sqrt(h), Math.sqrt(Math.max(0, 1 - h)));
}

function stopGPS() {
  if (gpsWatchId !== null && navigator.geolocation) navigator.geolocation.clearWatch(gpsWatchId);
  gpsWatchId = null;
}
function stopTimer() { clearInterval(runTimer); runTimer = null; }
function startTimer() {
  stopTimer();
  runTimer = setInterval(() => {
    if (!tracking || paused) return;
    data.run.seconds = runSeconds();
    updateRunDisplay();
  }, 1000);
}

function onPosition(pos) {
  const c = pos.coords, now = Date.now();
  if (c.accuracy > 40) { $("gpsStatus").textContent = `Weak GPS signal (±${Math.round(c.accuracy)} m). Move to open sky.`; return; }
  const cur = { latitude: c.latitude, longitude: c.longitude };
  $("gpsStatus").textContent = "GPS active. Keep this screen open.";
  if (!lastPoint) { lastPoint = cur; lastTime = now; return; }

  const d = distanceKm(lastPoint, cur);
  const minMove = Math.max(4, c.accuracy * 0.5) / 1000;   // ignore GPS jitter, but keep the anchor
  if (d < minMove) return;                                 // FIXED: anchor only moves when you really moved

  const dt = (now - lastTime) / 1000;
  if (dt <= 0 || d * 1000 / dt > 12) { lastPoint = cur; lastTime = now; return; }  // impossible jump (>43 km/h)

  data.run.distance += d;
  data.run.calories += met(d / (dt / 3600)) * latestWeight() * dt / 3600;
  if (!motionOn) addSteps(Math.round(d * 1000 / strideM()));
  lastPoint = cur; lastTime = now;
  saveData(); updateRunDisplay();

  const mark = Math.floor(data.run.distance);
  if (mark > lastKmMark) { lastKmMark = mark; notify("Kilometre reached", `${mark} km done · pace ${formatPace(data.run.distance, runSeconds())} /km`, "km"); }
}

function startGPS() {
  if (!navigator.geolocation) { $("gpsStatus").textContent = "GPS is not supported in this browser."; return; }
  lastPoint = null;
  gpsWatchId = navigator.geolocation.watchPosition(onPosition, err => {
    $("gpsStatus").textContent = ({ 1: "Location permission denied. Allow it in site settings.", 2: "GPS location unavailable.", 3: "GPS request timed out." })[err.code] || "Could not access GPS.";
  }, { enableHighAccuracy: true, maximumAge: 0, timeout: 20000 });
}

$("startRun").addEventListener("click", () => {
  if (tracking) {
    if (!paused) { runAccum = runSeconds(); paused = true; stopGPS(); }
    else { segStart = Date.now(); paused = false; startGPS(); }
    $("startRun").textContent = paused ? "Resume run" : "Pause run";
    $("gpsStatus").textContent = paused ? "Run paused." : "Run resumed.";
    return;
  }
  if (!navigator.geolocation) { $("gpsStatus").textContent = "GPS is not supported in this browser."; return; }
  tracking = true; paused = false; runAccum = 0; segStart = Date.now(); lastKmMark = 0;
  data.run = { distance: 0, seconds: 0, calories: 0 };
  $("startRun").textContent = "Pause run";
  $("stopRun").disabled = false;
  $("gpsStatus").textContent = "Requesting location permission…";
  requestWake(); startTimer(); startGPS(); saveData(); updateRunDisplay();
});

$("stopRun").addEventListener("click", () => {
  const sec = runSeconds();
  stopGPS(); stopTimer();
  tracking = false; paused = false; lastPoint = null; runAccum = sec;
  data.run.seconds = sec;
  if (data.run.distance >= 0.01) {
    data.runs.unshift({ date: new Date().toLocaleString("en", { day: "numeric", month: "short", hour: "numeric", minute: "2-digit" }), km: data.run.distance, sec, kcal: data.run.calories });
    data.runs = data.runs.slice(0, 20);
  }
  saveData(); releaseWake();
  $("startRun").textContent = "Start new run";
  $("stopRun").disabled = true;
  $("gpsStatus").textContent = "Run finished and saved.";
  renderRuns(); updateRunDisplay();
});

// ---------- Sound ----------
let audioCtx = null;
function unlockAudio() {
  try { audioCtx = audioCtx || new (window.AudioContext || window.webkitAudioContext)(); audioCtx.resume && audioCtx.resume(); } catch {}
}
function beep(freq = 880, dur = 0.18, when = 0) {
  if (!data.settings.sound) return;
  try {
    unlockAudio();
    const t = audioCtx.currentTime + when, o = audioCtx.createOscillator(), g = audioCtx.createGain();
    o.type = "sine"; o.frequency.value = freq;
    g.gain.setValueAtTime(0.0001, t);
    g.gain.exponentialRampToValueAtTime(0.5, t + 0.02);
    g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    o.connect(g); g.connect(audioCtx.destination); o.start(t); o.stop(t + dur + 0.05);
  } catch {}
}
const alarm = () => { [0, 0.3, 0.6].forEach(w => beep(988, 0.22, w)); if (navigator.vibrate) navigator.vibrate([300, 150, 300, 150, 300]); };
const chime = () => { beep(660, 0.15, 0); beep(880, 0.15, 0.18); beep(1175, 0.3, 0.36); };

// ---------- Rest timer ----------
let restInterval = null, restEnd = 0, restLength = data.settings.restLength || 60, restSeconds = restLength;
const renderRest = () => { $("restTimer").textContent = formatTime(restSeconds).slice(3); };
const cancelNativeRest = () => { if (NATIVE) LN.cancel({ notifications: [{ id: 300 }] }).catch(() => {}); };

function setRestLength(n) {
  clearInterval(restInterval); restInterval = null; cancelNativeRest();
  restLength = Math.min(3599, Math.max(5, Math.floor(n)));
  restSeconds = restLength;
  data.settings.restLength = restLength; saveData();
  $("restInput").value = restLength;
  $("startRest").textContent = `Start ${restLength} sec`;
  renderRest();
}
document.querySelectorAll("[data-rest]").forEach(b => b.addEventListener("click", () => setRestLength(Number(b.dataset.rest))));
$("restSet").addEventListener("click", () => {
  const n = safeNumber($("restInput").value, 0);
  if (n < 5 || n > 3599) return toast("Enter between 5 and 3599 seconds.");
  setRestLength(n); toast(`Rest timer set to ${restLength} sec.`);
});
$("soundOn").addEventListener("change", () => { data.settings.sound = $("soundOn").checked; saveData(); if ($("soundOn").checked) beep(880, 0.15); });

function restTick() {
  restSeconds = Math.max(0, Math.ceil((restEnd - Date.now()) / 1000));
  renderRest();
  if (restSeconds > 0 && restSeconds <= 3) beep(660, 0.1);
  if (restSeconds <= 0) {
    clearInterval(restInterval); restInterval = null; restSeconds = restLength; renderRest();
    $("startRest").textContent = `Start ${restLength} sec`;
    alarm();
    if (NATIVE) toast("Rest over. Time for your next set."); else notify("Rest over", "Time for your next set.", "rest");
  }
}

$("startRest").addEventListener("click", () => {
  unlockAudio();
  if (restInterval) {
    clearInterval(restInterval); restInterval = null; cancelNativeRest();
    restSeconds = Math.max(1, Math.ceil((restEnd - Date.now()) / 1000));
    $("startRest").textContent = "Resume timer"; return;
  }
  if (restSeconds <= 0) restSeconds = restLength;
  restEnd = Date.now() + restSeconds * 1000;
  $("startRest").textContent = "Pause timer";
  if (NATIVE) LN.schedule({ notifications: [{ id: 300, title: "Rest over", body: "Time for your next set.", schedule: { at: new Date(restEnd), allowWhileIdle: true } }] }).catch(() => {});
  restInterval = setInterval(restTick, 250);
});
$("resetRest").addEventListener("click", () => setRestLength(restLength));

// ---------- Export / delete ----------
$("exportData").addEventListener("click", () => {
  const url = URL.createObjectURL(new Blob([JSON.stringify(data, null, 2)], { type: "application/json" }));
  const a = document.createElement("a");
  a.href = url; a.download = "fitcoach-backup.json"; a.click();
  URL.revokeObjectURL(url);
});

$("clearData").addEventListener("click", () => {
  if (!confirm("Delete all locally saved FitCoach data? Export a backup first if needed.")) return;
  stopGPS(); stopTimer(); tracking = false; paused = false; runAccum = 0;
  localStorage.removeItem(STORAGE_KEY);
  data = loadData(); rollDay();
  $("startRun").textContent = "Start run"; $("stopRun").disabled = true;
  $("gpsStatus").textContent = "Ready.";
  setRestLength(60);
  render();
});

rollDay();
render();
renderRest();
$("startRest").textContent = `Start ${restLength} sec`; $("restInput").value = restLength; $("soundOn").checked = data.settings.sound !== false;
checkReminders();
autoStartSteps();
scheduleNative();
