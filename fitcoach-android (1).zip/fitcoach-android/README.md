# FitCoach Android app (works offline, counts steps with screen off)

The web files live in `www/` and are bundled inside the app, so it runs fully offline.
Steps come from the phone's hardware step sensor, which counts with the screen off.

## Build the APK
1. Install Node.js (18+) and Android Studio.
2. In this folder run:  ./setup.sh      (Windows: use Git Bash)
3. Run:  npx cap open android   -> in Android Studio: Build > Build APK(s)
   The APK is in android/app/build/outputs/apk/debug/app-debug.apk
4. Copy the APK to your phone and install it.

## First launch on the phone
- Allow "Physical activity", "Notifications" and "Location" when asked.
- Settings > Apps > FitCoach > Battery > Unrestricted (so reminders are not delayed).

## Manual steps (if setup.sh fails)
- npm install && npx cap add android
- Copy android-files/*.java to android/app/src/main/java/com/atul/fitcoach/
- Add these permissions inside android/app/src/main/AndroidManifest.xml, above <application>:
  ACTIVITY_RECOGNITION, POST_NOTIFICATIONS, ACCESS_FINE_LOCATION, ACCESS_COARSE_LOCATION
- npx cap sync android

## Limits
- GPS run tracking still needs the app open with the screen on.
- Steps taken before the first launch are not counted; counting starts from install.
