package com.atul.fitcoach;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.provider.Settings;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Handler;
import android.os.Looper;
import com.getcapacitor.JSObject;
import com.getcapacitor.PermissionState;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;
import com.getcapacitor.annotation.Permission;
import com.getcapacitor.annotation.PermissionCallback;
import java.util.ArrayList;
import java.util.List;

// Reads the hardware step counter (total steps since phone boot).
// The hardware keeps counting with the screen off, even when the app is closed.
// A listener stays registered while the app process is alive so the latest value is always ready.
@CapacitorPlugin(
    name = "StepCounter",
    permissions = { @Permission(strings = { Manifest.permission.ACTIVITY_RECOGNITION }, alias = "activity") }
)
public class StepCounterPlugin extends Plugin {

    private SensorManager sm;
    private Sensor stepSensor;
    private boolean registered = false;
    private float latest = -1f;
    private float lastKnown = -1f;
    private final List<PluginCall> waiting = new ArrayList<>();
    private final Handler handler = new Handler(Looper.getMainLooper());

    private final SensorEventListener listener = new SensorEventListener() {
        @Override public void onSensorChanged(SensorEvent e) {
            latest = e.values[0];
            lastKnown = latest;
            for (PluginCall c : new ArrayList<>(waiting)) resolveTotal(c);
            waiting.clear();
        }
        @Override public void onAccuracyChanged(Sensor s, int a) {}
    };

    @Override
    public void load() {
        sm = (SensorManager) getContext().getSystemService(Context.SENSOR_SERVICE);
        stepSensor = sm.getDefaultSensor(Sensor.TYPE_STEP_COUNTER);
        if (getPermissionState("activity") == PermissionState.GRANTED) register();
    }

    private void register() {
        if (registered || stepSensor == null) return;
        registered = sm.registerListener(listener, stepSensor, SensorManager.SENSOR_DELAY_NORMAL, 0);
    }

    private void resolveTotal(PluginCall call) {
        JSObject o = new JSObject();
        o.put("total", (double) latest);
        call.resolve(o);
    }

    @PluginMethod
    public void getTotal(PluginCall call) {
        if (stepSensor == null) { call.reject("No step sensor on this phone"); return; }
        if (getPermissionState("activity") != PermissionState.GRANTED) {
            requestPermissionForAlias("activity", call, "permDone");
            return;
        }
        read(call);
    }

    @PluginMethod
    public void openSettings(PluginCall call) {
        Intent i = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.fromParts("package", getContext().getPackageName(), null));
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        getContext().startActivity(i);
        call.resolve();
    }

    @PermissionCallback
    private void permDone(PluginCall call) {
        if (getPermissionState("activity") == PermissionState.GRANTED) read(call);
        else call.reject("Physical activity permission denied");
    }

    private void read(final PluginCall call) {
        // Re-register every time so Android sends the freshest total right away.
        // A cached value can be stale after the screen was off.
        sm.unregisterListener(listener);
        registered = false;
        latest = -1f;
        register();
        if (!registered) { call.reject("Could not start the step sensor"); return; }
        waiting.add(call);
        sm.flush(listener);
        handler.postDelayed(() -> {
            if (waiting.remove(call)) {
                if (lastKnown >= 0) { latest = lastKnown; resolveTotal(call); }
                else call.reject("Step sensor has no data yet. Walk a few steps");
            }
        }, 6000);
    }
}
