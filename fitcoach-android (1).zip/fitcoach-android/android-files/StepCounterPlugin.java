package com.atul.fitcoach;

import android.Manifest;
import android.content.Context;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Handler;
import android.os.Looper;
import com.getcapacitor.JSObject;
import com.getcapacitor.PermissionState;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;
import com.getcapacitor.annotation.Permission;
import com.getcapacitor.annotation.PermissionCallback;
import java.util.concurrent.atomic.AtomicBoolean;

// Reads the hardware step counter (total steps since phone boot).
// The sensor keeps counting with the screen off, even when the app is closed.
@CapacitorPlugin(
    name = "StepCounter",
    permissions = { @Permission(strings = { Manifest.permission.ACTIVITY_RECOGNITION }, alias = "activity") }
)
public class StepCounterPlugin extends Plugin {

    @PluginMethod
    public void getTotal(PluginCall call) {
        if (getPermissionState("activity") != PermissionState.GRANTED) {
            requestPermissionForAlias("activity", call, "permDone");
            return;
        }
        read(call);
    }

    @PermissionCallback
    private void permDone(PluginCall call) {
        if (getPermissionState("activity") == PermissionState.GRANTED) read(call);
        else call.reject("Permission denied");
    }

    private void read(PluginCall call) {
        final SensorManager sm = (SensorManager) getContext().getSystemService(Context.SENSOR_SERVICE);
        final Sensor sensor = sm.getDefaultSensor(Sensor.TYPE_STEP_COUNTER);
        if (sensor == null) { call.reject("No step sensor on this phone"); return; }

        final AtomicBoolean done = new AtomicBoolean(false);
        final SensorEventListener listener = new SensorEventListener() {
            @Override public void onSensorChanged(SensorEvent e) {
                if (!done.compareAndSet(false, true)) return;
                sm.unregisterListener(this);
                JSObject o = new JSObject();
                o.put("total", (double) e.values[0]);
                call.resolve(o);
            }
            @Override public void onAccuracyChanged(Sensor s, int a) {}
        };
        sm.registerListener(listener, sensor, SensorManager.SENSOR_DELAY_NORMAL, 0);
        sm.flush(listener);

        new Handler(Looper.getMainLooper()).postDelayed(() -> {
            if (done.compareAndSet(false, true)) {
                sm.unregisterListener(listener);
                call.reject("Step sensor gave no data");
            }
        }, 10000);
    }
}
